package com.example.minesweeper

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.FieldPosition
import java.util.Calendar
import java.util.Timer

class TheGame : AppCompatActivity(),onCellClickListener{
    //Variable Declaration and view initialization
    var rows: Int = 0
    var columns: Int = 0
    var mines: Int = 0
    var gameTime: Int = 0
    var clickMode: Boolean = true
    var firstClick: Boolean = false
    var hasWon = false
    var bestGameTime = 999
    lateinit var grid: RecyclerView
    lateinit var mineGridRecyclerAdapter: MineGridRecyclerAdapter
    lateinit var gameBoard: Mainboard
    lateinit var gameMode: Button
    lateinit var no_of_flags_left: TextView
    lateinit var reset: Button
    lateinit var timer: TextView
    lateinit var calender: Calendar
    lateinit var countDownTimer: CountDownTimer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_the_game)

        //Getting data from MainActivity
        rows = intent.getIntExtra("noofrows",2)
        columns = intent.getIntExtra("noofcolumns",2)
        mines = intent.getIntExtra("noofmines",1)
        gameTime = intent.getIntExtra("time",0)
        bestGameTime = intent.getIntExtra("bestGameTime",999)

        //Board Creation
        gameBoard = Mainboard(rows, columns,mines)

        //View Deceleration
        gameMode = findViewById(R.id.game_mode)
        no_of_flags_left = findViewById(R.id.no_of_flags)
        reset = findViewById(R.id.restart)

        //Countdown Timer
        timer = findViewById(R.id.time)
        countDownTimer = object : CountDownTimer(gameTime.toLong()*1000,1000){
            override fun onTick(p0: Long) {
                var timeLeft = (p0/1000).toString()
                timer.setText(timeLeft)
            }

            override fun onFinish() {
                mineGridRecyclerAdapter.apply {
                    Toast.makeText(this@TheGame,"You Lost",Toast.LENGTH_SHORT).show()
                    var changesCells: List<Cell> = revealAllMines()
                    changeBoard(changesCells)
                    gameOver()
                    countDownTimer.cancel()
                    gameMode.isEnabled = false
                }
            }

        }


        //Setting GameMode
        gameMode.isEnabled = false
        gameMode.setOnClickListener{
            clickMode = !clickMode
            if(!clickMode){
                gameMode.setText(R.string.bomb)
            }else{
                gameMode.setText(R.string.flag)
            }
        }

        //Reset Button Function
        reset.setOnClickListener {
            clickMode= true
            firstClick= false
            hasWon = false
            countDownTimer.cancel()
            countDownTimer.start()
            val size = gameBoard.Cells.size
            for (i in 0..(size-1)){
                gameBoard.Cells.removeAt(0)
            }
            val size2 = gameBoard.flaggedCells.size
            for (i in 0..(size2-1)){
                gameBoard.flaggedCells.removeAt(0)
            }
            val size3 = gameBoard.minedCell.size
            for (i in 0..(size3-1)){
                gameBoard.minedCell.removeAt(0)
            }
            grid = findViewById<RecyclerView>(R.id.mine_grid).apply {
                layoutManager = GridLayoutManager(this@TheGame,columns)
                mineGridRecyclerAdapter = MineGridRecyclerAdapter().apply {
                    MineGridRecyclerAdapterFun(rows,columns,this@TheGame,gameBoard.getBoard())
                }
                adapter = mineGridRecyclerAdapter
                setHasFixedSize(true)
            }
        }

        //Setting RecyclerView
        grid = findViewById<RecyclerView>(R.id.mine_grid).apply {
            layoutManager = GridLayoutManager(this@TheGame,columns)
            mineGridRecyclerAdapter = MineGridRecyclerAdapter().apply {
                MineGridRecyclerAdapterFun(rows,columns,this@TheGame,gameBoard.getBoard())
            }
            adapter = mineGridRecyclerAdapter
            setHasFixedSize(true)
        }

    }

    //Starting Timer on Game Start
    override fun onStart() {
        super.onStart()
        countDownTimer.start()
    }

    //Stopping Timer on Game Stop
    override fun onStop() {
        super.onStop()
        countDownTimer.cancel()
    }

    //Handling Cell Click
    override fun cellClick(cell: Cell,position: Int) {
//        Toast.makeText(this,"${position},${gameBoard.Cells[position].getAdjCells()}",Toast.LENGTH_SHORT).show()
        no_of_flags_left.text = (gameBoard.minedCell.size - gameBoard.flaggedCells.size).toString()
        if (firstClick){
            if(clickMode) {
                if (cell.isCellMine()) {
                    Toast.makeText(this,"You Lost",Toast.LENGTH_SHORT).show()
                    var changesCells: List<Cell> = revealAllMines()
                    mineGridRecyclerAdapter.apply {
                        changeBoard(changesCells)
                        gameOver()
                        countDownTimer.cancel()
                        gameMode.isEnabled = false
                    }
                } else {
                    var revealList = gameBoard.revealRelevant(position)
                    mineGridRecyclerAdapter.apply {
                        changeBoard(revealList)
                    }
                    hasWon = gameBoard.checkWon()
                    if(hasWon){
                        Toast.makeText(this,"You have Won",Toast.LENGTH_SHORT).show()
                        val currentGameTime = gameTime - Integer.parseInt(timer.text.toString())
                        println(currentGameTime)
                        val goToMain = Intent(this,MainActivity::class.java).apply {
                            putExtra("previousGameTime",currentGameTime)
                        }
                        startActivity(goToMain)
                    }
                }
            }else{
                if(!gameBoard.Cells[position].isCellReveal()){
                    gameBoard.Cells[position].setFlagged()
                    if (gameBoard.Cells[position].isCellFlagged()){
                        gameBoard.flaggedCells.add(gameBoard.Cells[position])
                    }else{
                        gameBoard.flaggedCells.remove(gameBoard.Cells[position])
                    }

                    mineGridRecyclerAdapter.apply {
                        changeBoard(gameBoard.Cells)
                    }
                }
                hasWon = gameBoard.checkWon()
                if(hasWon){
                    Toast.makeText(this,"You have Won",Toast.LENGTH_SHORT).show()
                    val currentGameTime = gameTime - Integer.parseInt(timer.text.toString())
                    println(currentGameTime)
                    val goToMain = Intent(this,MainActivity::class.java).apply {
                        putExtra("previousGameTime",currentGameTime)
                    }
                    startActivity(goToMain)

                }
            }
            no_of_flags_left.text = (gameBoard.minedCell.size - gameBoard.flaggedCells.size).toString()
            if(Integer.parseInt(no_of_flags_left.text.toString()) == 0){
                hasWon = gameBoard.checkWon()
                if(hasWon){
                    Toast.makeText(this,"You have Won",Toast.LENGTH_SHORT).show()
                    val currentGameTime = gameTime - Integer.parseInt(timer.text.toString())
                    println(currentGameTime)
                    val goToMain = Intent(this,MainActivity::class.java).apply {
                        putExtra("previousGameTime",currentGameTime)
                    }
                    startActivity(goToMain)

                }else{
                    mineGridRecyclerAdapter.apply {
                        Toast.makeText(this@TheGame,"You Lost",Toast.LENGTH_SHORT).show()
                        var changesCells: List<Cell> = revealAllMines()
                        changeBoard(changesCells)
                        gameOver()
                        countDownTimer.cancel()
                        gameMode.isEnabled = false
                    }
                }
            }
        }else{
            var changesCells: List<Cell> = setCellMines(position)
            var revealList = gameBoard.revealRelevant(position)
            mineGridRecyclerAdapter.apply {
                changeBoard(changesCells)
                changeBoard(revealList)
            }
            firstClick = true
            gameMode.isEnabled = true
            no_of_flags_left.text = (gameBoard.minedCell.size - gameBoard.flaggedCells.size).toString()
            hasWon = gameBoard.checkWon()
            if(hasWon){
                Toast.makeText(this,"You have Won",Toast.LENGTH_SHORT).show()
                val goToMain = Intent(this,MainActivity::class.java)
                startActivity(goToMain)
            }
        }



    }

    //Setting Mines
    fun setCellMines(cellClickPostion: Int): MutableList<Cell> {
        return gameBoard.updateBoard(cellClickPostion)
    }

    //Revealing all Mines
    fun revealAllMines(): MutableList<Cell> {
        return gameBoard.revealAll()
    }

}

