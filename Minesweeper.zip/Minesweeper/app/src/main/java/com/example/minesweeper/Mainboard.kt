package com.example.minesweeper

import android.provider.MediaStore.Audio.AlbumColumns
import android.util.Log.i
import kotlin.random.Random

class Mainboard(rows: Int, columns: Int,mines: Int) {
    // Initializing Variables
    var rows: Int = rows
    var columns: Int = columns
    val mines:Int = mines
    val Cells = mutableListOf<Cell>()
    val revealedCell = mutableListOf<Int>()
    val flaggedCells = mutableListOf<Cell>()
    val minedCell = mutableListOf<Cell>()

    //Creating a Game Board
    fun getBoard(): MutableList<Cell> {
        for (i in 1..rows){
            val colList = mutableListOf<Cell>()
            for (i in 1..columns){
                Cells.add(Cell())
            }

        }
        return Cells
    }

    // Updating Board after First Click
    fun updateBoard(cellClickedPosition: Int): MutableList<Cell> {
        val pos = toXY(cellClickedPosition,rows)
        var noofminesplaced: Int = 0
        //Placing Mines
        while (noofminesplaced<mines){
            val x = Random.nextInt(columns)
            val y = Random.nextInt(rows)
            val position = toPosition(x,y)
            println(noofminesplaced)
            if ((x != pos[0] && y != pos[1]) && !Cells[position].isCellMine()){
                Cells[position].setMine()
                minedCell.add(Cells[position])
                noofminesplaced++
            }
        }

        //Setting adjacent Cells
        for(cell in 0..Cells.size-1){
            val adjCells = adjacentCells(cell)
            Cells[cell].setAdjCells(adjCells)
        }

        //Setting Cell Values
        for (i in 0..Cells.size-1){
            if(!Cells[i].isCellMine()){
                val adjPos = Cells[i].getAdjCells()
                var noOfAdjMines = 0
                for (j in adjPos){
                    if (Cells[j].isCellMine()){
                        noOfAdjMines++
                    }
                }
                Cells[i].setCellvalue(noOfAdjMines)

            }
        }
        return Cells
    }

    // Revealing all the cells
    fun revealAll(): MutableList<Cell> {

        for(cell in Cells){
            cell.revealCell()
        }
        return Cells
    }

    //Converting position to XY coordinates
    fun toXY(position: Int,noRows: Int): List<Int>{
        var xy = mutableListOf <Int>()
        val x = (position/noRows)
        val y = (position - x*noRows)
        xy.add(x)
        xy.add(y)
        return xy
    }

    //XY to postion
    fun toPosition(x: Int,y: Int): Int {
        return ((x*rows) + y)
    }

    //Getting adjacent Cells
    fun adjacentCells(postion:Int): MutableList<Int>{
        val adjCells = mutableListOf<Int>()
        val posXY = toXY(postion,rows)
        val x = posXY[0]
        val y = posXY[1]
        val pos1 = toPosition(x-1,y-1)
        if(checkPostion(x-1,y-1,rows,columns) && !checkInList(pos1,adjCells)){
            adjCells.add(pos1)
        }
        val pos2 = toPosition(x-1,y)
        if(checkPostion(x-1,y,rows, columns) && !checkInList(pos2,adjCells)){
            adjCells.add(pos2)
        }
        val pos3 = toPosition(x-1,y+1)
        if(checkPostion(x-1,y+1,rows,columns) && !checkInList(pos3,adjCells)){
            adjCells.add(pos3)
        }
        val pos4 = toPosition(x,y+1)
        if(checkPostion(x,y+1,rows, columns) && !checkInList(pos4,adjCells)){
            adjCells.add(pos4)
        }
        val pos5 = toPosition(x+1,y+1)
        if(checkPostion(x+1,y+1,rows, columns) && !checkInList(pos5,adjCells)){
            adjCells.add(pos5)
        }
        val pos6 = toPosition(x+1,y)
        if(checkPostion(x+1,y,rows, columns) && !checkInList(pos6,adjCells)){
            adjCells.add(pos6)
        }
        val pos7 = toPosition(x+1,y-1)
        if(checkPostion(x+1,y-1,rows, columns) && !checkInList(pos7,adjCells)){
            adjCells.add(pos7)
        }
        val pos8 = toPosition(x,y-1)
        if(checkPostion(x,y-1,rows, columns) && !checkInList(pos8,adjCells)){
            adjCells.add(pos8)
        }

        return adjCells
    }

    //Checking Valid position
    fun checkPostion(x : Int,y : Int,rows : Int,columns: Int) : Boolean{
        return ((x < columns && x >= 0) && (y < rows && y >= 0))
    }

    //Utility Function
    fun checkInList(num: Int, list: MutableList<Int>): Boolean {
        for (i in list){
            if (i == num){
                return true
            }
        }
        return false
    }

    //Revealing relevant cells according to the clicked cell
    fun revealRelevant(pos: Int): MutableList<Cell>{
        var i = 0
        while (i < rows*columns){
            for(j in 1..columns){
                print(Cells[i].getCellValue())
                i++
            }
            println()
        }

        if(Cells[pos].getCellValue() != 0) {
            Cells[pos].revealCell()
            val adjCellList = Cells[pos].getAdjCells()
            for (i in adjCellList){
                if((!(Cells[i].isCellMine())) && (!(Cells[i].getCellValue() == 0)) && (!(Cells[i].isCellFlagged())) && (!Cells[i].isCellReveal())){
                    Cells[i].revealCell()
                    revealedCell.add(i)
                }
            }
        for (i in 0..Cells.size-1){
            if (Cells[i].isCellReveal() && !(revealedCell.contains(i))){
                revealedCell.add(i)
            }
        }
        println(revealedCell)
        }else{
            var cellsToBeRevealed = mutableListOf<Int>()
            Cells[pos].revealCell()
            cellsToBeRevealed.add(pos)
            while (!cellsToBeRevealed.isEmpty()){
                val adjCellList = Cells[cellsToBeRevealed[0]].getAdjCells()
                for (i in adjCellList){
                    if(Cells[i].getCellValue() == 0 && !Cells[i].isCellReveal()){
                        Cells[i].revealCell()
                        cellsToBeRevealed.add(i)
                    }else if(!Cells[i].isCellMine()){
                        Cells[i].revealCell()
                    }
                }
                cellsToBeRevealed.removeAt(0)
            }
        }
        return Cells
   }

    //Checking whether user has won
    fun checkWon(): Boolean{
        var hasWon = true
        for (cell in Cells){
            if (!cell.isCellReveal()){
                if (!(cell in minedCell)){
                    hasWon = false
                }
            }
        }
        for (cell in flaggedCells){
            if (!minedCell.contains(cell)){
                hasWon = false
                break
            }
        }
        val commonUnreveled = Cells.intersect(minedCell)
        if (commonUnreveled.size < minedCell.size){
            hasWon = true
        }

        val common = flaggedCells.intersect(minedCell)
        if (common.size == minedCell.size){
            hasWon = true
        }
        return hasWon
    }
}