package com.example.minesweeper

class Cell {
    // Variable Initialization
    private var isBlank: Boolean = true
    private var value: Int = -1
    private var isRevealed: Boolean = false
    private var isMine: Boolean = false
    private var isFlagged: Boolean = false
    private var adjCell: MutableList<Int> = mutableListOf()

    //Getters and Setters
    fun isCellMine(): Boolean {
        return isMine
    }

    fun setMine(){
        isBlank = false
        isMine = true
    }

    fun isCellFlagged(): Boolean {
        return isFlagged
    }

    fun setFlagged(){
        isFlagged = !isFlagged
    }

    fun isCellReveal(): Boolean {
        return isRevealed
    }

    fun revealCell(){
        isRevealed = true
    }

    fun setCellvalue(num: Int){
        value = num
    }

    fun getCellValue(): Int{
        return value
    }

    fun setAdjCells(list : MutableList<Int>){
        adjCell = list
    }

    fun getAdjCells(): MutableList<Int> {
        return adjCell
    }
}