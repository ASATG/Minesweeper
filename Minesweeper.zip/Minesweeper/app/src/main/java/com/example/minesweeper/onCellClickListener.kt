package com.example.minesweeper

interface onCellClickListener {
    fun cellClick(cell: Cell, position: Int)
}