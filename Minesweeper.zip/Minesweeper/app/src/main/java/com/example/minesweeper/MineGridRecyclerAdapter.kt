package com.example.minesweeper

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class MineGridRecyclerAdapter(): RecyclerView.Adapter<MineGridRecyclerAdapter.Cell>() {
    var numberofrows: Int = 0
    var numberofcolumns: Int = 0
    var gameOver: Boolean = false

    lateinit var listener: onCellClickListener
    var cells = arrayOf<com.example.minesweeper.Cell>()

    set(value){
        field = value
        notifyDataSetChanged()
    }

    fun MineGridRecyclerAdapterFun(
        rows: Int, columns: Int, listener: onCellClickListener,
        mainboard: List<com.example.minesweeper.Cell>
    ){
        this.numberofrows = rows
        this.numberofcolumns = columns
        this.listener = listener
        cells = mainboard.toTypedArray()
    }

    override fun getItemCount(): Int {
        return cells.size
    }

    inner class Cell(v: View) : RecyclerView.ViewHolder(v){
        val cell: TextView = v.findViewById(R.id.cell)

        fun bind(cell: com.example.minesweeper.Cell,position: Int){
            itemView.setOnClickListener{
                if (this.cell.isEnabled){
                    listener.cellClick(cell,position)
                }
            }

            if (cell.isCellReveal() && !cell.isCellFlagged()){
                //Reveling the relevant Cells
                if(cell.isCellMine()){
                    this.cell.setText(R.string.bomb)
                }
                else if(cell.getCellValue()!=0){
                    this.cell.setText(cell.getCellValue().toString())

                }
                this.cell.setBackgroundColor(Color.parseColor("#A9B7D5"))
                this.cell.isEnabled = false
            }else if (cell.isCellFlagged()){
                this.cell.setText(R.string.flag)
            }

            //Actions after the game is Over
            if(gameOver){
                this.cell.isEnabled = false
                this.cell.setBackgroundColor(Color.parseColor("#D3D3D3"))
            }


        }


    }

    //Changes in the board
    fun changeBoard(list : List<com.example.minesweeper.Cell>){
        cells = list.toTypedArray()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Cell {
        val itemLayout = LayoutInflater.from(parent.context).inflate(R.layout.cell_layout,parent,false)

        return Cell(itemLayout)
    }

    override fun onBindViewHolder(holder: Cell, position: Int) {
        holder.bind(cells.get(position),position)
    }

    fun gameOver(){
        gameOver = true
    }
}