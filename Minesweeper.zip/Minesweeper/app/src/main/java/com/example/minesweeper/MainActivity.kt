package com.example.minesweeper

import android.content.Context
import android.content.Intent
import android.icu.lang.UCharacter.GraphemeClusterBreak.T
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.isVisible

const val BEST_TIME = "BEST_TIME"
const val LAST_TIME = "LAST_TIME"
class MainActivity : AppCompatActivity() {
    //Variable Declaration and view initialization
    lateinit var radioGroup: RadioGroup
    lateinit var startButton: Button
    lateinit var customButton: Button
    lateinit var best_time: TextView
    lateinit var numberofrows: EditText
    lateinit var numberofcolumns: EditText
    lateinit var numberofmines: EditText
    lateinit var select_difficulty: TextView
    lateinit var timeTaken: EditText
    lateinit var lastGameTimeText: TextView

    var no_of_rows: Int = 0
    var no_of_columnns: Int = 0
    var no_of_mines: Int = 0
    var time: Int = 0
    var useCuston: Boolean = false
    var bestGameTime: Int = Int.MAX_VALUE
    var lastlastgameTime: Int = 0



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Loading and Saving Game Times
        loadTimes()
        var lastGameTime = intent.getIntExtra("previousGameTime",lastlastgameTime)
        println(lastGameTime)
        if (lastGameTime < bestGameTime && lastGameTime!=0){
            bestGameTime = lastGameTime
        }

        saveTimes(bestGameTime,lastGameTime)
//
        best_time = findViewById(R.id.best_time)
        best_time.setText("Best Time: ${bestGameTime}")

        lastGameTimeText = findViewById(R.id.lastGameTime)
        lastGameTimeText.setText("Last Game Time: ${lastGameTime}")

        //View declaration
        radioGroup = findViewById(R.id.difficulty_level)
        startButton = findViewById(R.id.start)
        customButton = findViewById(R.id.make_custom_board)
        numberofrows = findViewById(R.id.no_of_rows)
        numberofcolumns = findViewById(R.id.no_of_columns)
        numberofmines = findViewById(R.id.no_of_mines)
        select_difficulty = findViewById(R.id.select_difficulty)
        timeTaken = findViewById(R.id.game_time)
        numberofrows.isVisible = false
        numberofcolumns.isVisible = false
        numberofmines.isVisible = false
        timeTaken.isVisible = false

        //Custom Button Action
        customButton.setOnClickListener{
            numberofrows.isVisible = true
            numberofcolumns.isVisible = true
            numberofmines.isVisible =true
            timeTaken.isVisible = true
            radioGroup.isVisible = false
            radioGroup.clearCheck()
            useCuston = true
        }

        //Select Difficulty TextView Action
        select_difficulty.setOnClickListener{
            numberofrows.isVisible = false
            numberofcolumns.isVisible = false
            numberofmines.isVisible =false
            timeTaken.isVisible = false
            radioGroup.isVisible = true
            radioGroup.check(R.id.easy)
            useCuston = false
        }

        // StartButton Action
        startButton.setOnClickListener {
            if (useCuston){
                customEntry()
            }else{
                usingDifficulty()
            }
        }
        best_time = findViewById(R.id.best_time)
    }

    //When Custon Entry is selected
    private fun customEntry(){
        if (numberofrows.text.toString() == ""){
            no_of_rows = 0
        }else{
            no_of_rows = Integer.parseInt(numberofrows.text.toString())
        }
        if (numberofcolumns.text.toString() == ""){
            no_of_columnns = 0
        }else{
            no_of_columnns = Integer.parseInt(numberofcolumns.text.toString())
        }
        if (numberofmines.text.toString() == ""){
            no_of_mines = 0
        }else{
            no_of_mines = Integer.parseInt(numberofmines.text.toString())
        }
        if (timeTaken.text.toString() == ""){
            time = 0
        }else{
            time = Integer.parseInt(timeTaken.text.toString())
        }

        val max_mines: Int = (no_of_columnns*no_of_rows)/4
        if(no_of_rows < 2){
            Toast.makeText(this,"Enter more than 2 row",Toast.LENGTH_SHORT).show()
        }else if (no_of_columnns < 2){
            Toast.makeText(this,"Enter more than 2 columns",Toast.LENGTH_SHORT).show()
        }else if(no_of_mines < 1){
            Toast.makeText(this,"Enter atleast 1 mine",Toast.LENGTH_SHORT).show()
        }else if (no_of_mines > max_mines){
            Toast.makeText(this,"Enter less than ${max_mines+1} mines",Toast.LENGTH_SHORT).show()
        }else if(time <= 0){
            Toast.makeText(this, "Please entre a reasonable Time",Toast.LENGTH_SHORT).show()
        }else{
            val goToGame =Intent(this, TheGame::class.java).apply {
                putExtra("noofrows",no_of_rows)
                putExtra("noofcolumns",no_of_columnns)
                putExtra("noofmines",no_of_mines)
                putExtra("time",time)
                putExtra("bestGameTime",bestGameTime)
            }
            startActivity(goToGame)
        }
    }

    //If difficulty level is selected
    private fun usingDifficulty(){
        radioGroup = findViewById(R.id.difficulty_level)
        val radioButtonid = radioGroup.checkedRadioButtonId
        if(radioButtonid == R.id.easy){
            no_of_rows = 6
            no_of_columnns = 6
            no_of_mines = 6
            time = 250
        }else if(radioButtonid == R.id.medium){
            no_of_rows = 10
            no_of_columnns = 10
            no_of_mines = 20
            time = 350
        }else if(radioButtonid == R.id.hard){
            no_of_rows = 13
            no_of_columnns = 13
            no_of_mines = 40
            time = 350
        }
        val goToGame =Intent(this, TheGame::class.java).apply {
            putExtra("noofrows",no_of_rows)
            putExtra("noofcolumns",no_of_columnns)
            putExtra("noofmines",no_of_mines)
            putExtra("time",time)
        }
        startActivity(goToGame)
    }

    //Function to save Times
    private fun saveTimes(BGT:Int,LGT:Int){
        val Times = mutableListOf<String>(BGT.toString(),LGT.toString())
        val sharedPref = getPreferences(Context.MODE_PRIVATE)
        with(sharedPref.edit()){
            putInt(BEST_TIME, BGT)
            putInt(LAST_TIME,LGT)
            commit()
        }
    }

    //Function to load Times
    private fun loadTimes(){
        val sharedPref = getPreferences(Context.MODE_PRIVATE)
        val BTime = sharedPref.getInt(BEST_TIME, Int.MAX_VALUE)
        bestGameTime = BTime
        val LTime = sharedPref.getInt(LAST_TIME, 0)
        lastlastgameTime = LTime
    }
}